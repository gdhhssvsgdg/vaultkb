package com.vaultkb

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.UUID
import java.util.zip.ZipInputStream

object SheetImport {

    class Sheet(val name: String, val rows: List<List<String>>)

    fun parse(bytes: ByteArray): List<Account> {
        if (bytes.size > 4 && bytes[0] == 0xD0.toByte() && bytes[1] == 0xCF.toByte()) {
            throw Exception("الملف بصيغة xls القديمة، احفظه xlsx أو CSV")
        }
        val isXlsx = bytes.size > 3 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()
        val sheets = if (isXlsx) readXlsx(bytes) else listOf(Sheet("عام", readCsv(bytes)))
        return toAccounts(sheets)
    }

    // ---------------- xlsx ----------------

    private fun parser(data: ByteArray): XmlPullParser {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(data), "UTF-8")
        return p
    }

    private fun readXlsx(bytes: ByteArray): List<Sheet> {
        val files = HashMap<String, ByteArray>()
        val zin = ZipInputStream(ByteArrayInputStream(bytes))
        var e = zin.nextEntry
        while (e != null) {
            if (!e.isDirectory) files[e.name] = zin.readBytes()
            e = zin.nextEntry
        }
        zin.close()

        // shared strings
        val shared = ArrayList<String>()
        val ssData = files["xl/sharedStrings.xml"]
        if (ssData != null) {
            val p = parser(ssData)
            var sb: StringBuilder? = null
            var inPh = false
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    val n = p.name
                    if (n == "si") {
                        sb = StringBuilder()
                    } else if (n == "rPh") {
                        inPh = true
                    } else if (n == "t") {
                        val txt = p.nextText()
                        if (!inPh && sb != null) sb.append(txt)
                    }
                } else if (ev == XmlPullParser.END_TAG) {
                    val n = p.name
                    if (n == "rPh") {
                        inPh = false
                    } else if (n == "si") {
                        shared.add(sb?.toString() ?: "")
                        sb = null
                    }
                }
                ev = p.next()
            }
        }

        // relationships: rId -> path
        val rels = HashMap<String, String>()
        val relData = files["xl/_rels/workbook.xml.rels"]
        if (relData != null) {
            val p = parser(relData)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
                    val id = p.getAttributeValue(null, "Id") ?: ""
                    var t = p.getAttributeValue(null, "Target") ?: ""
                    t = if (t.startsWith("/")) t.substring(1) else "xl/" + t
                    rels[id] = t
                }
                ev = p.next()
            }
        }

        // sheets: name + path
        val defs = ArrayList<Pair<String, String>>()
        val wbData = files["xl/workbook.xml"]
        if (wbData != null) {
            val p = parser(wbData)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && p.name == "sheet") {
                    val name = p.getAttributeValue(null, "name") ?: "عام"
                    var rid = ""
                    for (i in 0 until p.attributeCount) {
                        val an = p.getAttributeName(i)
                        if (an == "r:id" || an.endsWith(":id")) rid = p.getAttributeValue(i)
                    }
                    val path = rels[rid]
                    if (path != null) defs.add(Pair(name, path))
                }
                ev = p.next()
            }
        }
        if (defs.isEmpty()) {
            val keys = files.keys.filter { it.startsWith("xl/worksheets/sheet") }.sorted()
            for ((i, k) in keys.withIndex()) defs.add(Pair("شيت " + (i + 1), k))
        }

        val out = ArrayList<Sheet>()
        for (d in defs) {
            val data = files[d.second] ?: continue
            out.add(Sheet(d.first, readSheet(data, shared)))
        }
        return out
    }

    private fun readSheet(data: ByteArray, shared: List<String>): List<List<String>> {
        val rows = ArrayList<List<String>>()
        val p = parser(data)
        var row: ArrayList<String>? = null
        var col = 0
        var type = ""
        var value = StringBuilder()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                val n = p.name
                if (n == "row") {
                    row = ArrayList()
                } else if (n == "c") {
                    val ref = p.getAttributeValue(null, "r") ?: ""
                    col = if (ref.isNotEmpty()) colIndex(ref) else (row?.size ?: 0)
                    type = p.getAttributeValue(null, "t") ?: ""
                    value = StringBuilder()
                } else if (n == "v" || n == "t") {
                    value.append(p.nextText())
                }
            } else if (ev == XmlPullParser.END_TAG) {
                val n = p.name
                if (n == "c") {
                    val r = row
                    if (r != null) {
                        var s = value.toString()
                        if (type == "s") {
                            val idx = s.trim().toIntOrNull() ?: -1
                            s = shared.getOrElse(idx) { "" }
                        } else if (type == "" || type == "n") {
                            s = plainNumber(s)
                        }
                        while (r.size <= col) r.add("")
                        r[col] = s
                    }
                } else if (n == "row") {
                    val r = row
                    if (r != null) rows.add(r)
                    row = null
                }
            }
            ev = p.next()
        }
        return rows
    }

    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) {
            if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1)
            else if (ch in 'a'..'z') n = n * 26 + (ch - 'a' + 1)
            else break
        }
        return if (n > 0) n - 1 else 0
    }

    private fun plainNumber(s: String): String {
        val t = s.trim()
        if (t.isEmpty()) return s
        return try {
            java.math.BigDecimal(t).stripTrailingZeros().toPlainString()
        } catch (e: Exception) {
            s
        }
    }

    // ---------------- csv ----------------

    private fun decode(bytes: ByteArray): String {
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString()
        } catch (e: Exception) {
            try {
                String(bytes, charset("windows-1256"))
            } catch (e2: Exception) {
                String(bytes, Charsets.ISO_8859_1)
            }
        }
    }

    private fun readCsv(bytes: ByteArray): List<List<String>> {
        var text = decode(bytes)
        if (text.startsWith("\uFEFF")) text = text.substring(1)
        val firstLine = text.lineSequence().firstOrNull() ?: ""
        var delim = ','
        var best = -1
        for (d in listOf(',', ';', '\t')) {
            val c = firstLine.count { it == d }
            if (c > best) {
                best = c
                delim = d
            }
        }
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val cur = StringBuilder()
        var inQ = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (inQ) {
                if (c == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') {
                        cur.append('"')
                        i++
                    } else {
                        inQ = false
                    }
                } else {
                    cur.append(c)
                }
            } else {
                if (c == '"') {
                    inQ = true
                } else if (c == delim) {
                    row.add(cur.toString())
                    cur.setLength(0)
                } else if (c == '\n') {
                    row.add(cur.toString())
                    cur.setLength(0)
                    rows.add(row)
                    row = ArrayList()
                } else if (c != '\r') {
                    cur.append(c)
                }
            }
            i++
        }
        if (cur.isNotEmpty() || row.isNotEmpty()) {
            row.add(cur.toString())
            rows.add(row)
        }
        return rows
    }

    // ---------------- rows -> accounts ----------------

    private fun norm(s: String): String {
        return s.trim().lowercase()
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
            .replace('ة', 'ه').replace('ى', 'ي')
            .replace(" ", "")
    }

    private fun kind(cell: String): String {
        val s = norm(cell)
        if (s.isEmpty()) return ""
        if (s.contains("باسورد") || s.contains("باسوورد") || s.contains("password") ||
            s.contains("pass") || s.contains("كلمه") || s.contains("سري") || s == "pw"
        ) return "p"
        if (s.contains("ايميل") || s.contains("email") || s.contains("mail") ||
            s.contains("جيميل") || s.contains("جميل") || s.contains("مستخدم") || s.contains("user")
        ) return "e"
        if (s.contains("فئه") || s.contains("تصنيف") || s.contains("مجموعه") ||
            s.contains("group") || s.contains("categor") || s.contains("نوع") || s.contains("لعبه")
        ) return "g"
        if (s.contains("اسم") || s.contains("name") || s.contains("حساب") ||
            s.contains("account") || s.contains("title")
        ) return "n"
        return ""
    }

    private class Layout(
        val sh: Sheet,
        val rows: List<List<String>>,
        val gi: Int,
        val ni: Int,
        val ei: Int,
        val pi: Int,
        val start: Int,
        val found: Boolean
    )

    private fun layoutOf(sh: Sheet): Layout? {
        val rows = sh.rows.filter { r -> r.any { it.isNotBlank() } }
        if (rows.isEmpty()) return null
        var gi = -1
        var ni = -1
        var ei = -1
        var pi = -1
        val head = rows[0]
        for ((idx, cell) in head.withIndex()) {
            val k = kind(cell)
            if (k == "p" && pi < 0) pi = idx
            else if (k == "e" && ei < 0) ei = idx
            else if (k == "g" && gi < 0) gi = idx
            else if (k == "n" && ni < 0) ni = idx
        }
        if (ei >= 0 && pi >= 0) {
            return Layout(sh, rows, gi, ni, ei, pi, 1, true)
        }
        val w = head.size
        return if (w >= 4) {
            Layout(sh, rows, 0, 1, 2, 3, 0, false)
        } else if (w == 3) {
            Layout(sh, rows, -1, 0, 1, 2, 0, false)
        } else {
            Layout(sh, rows, -1, -1, 0, 1, 0, false)
        }
    }

    private fun toAccounts(sheets: List<Sheet>): List<Account> {
        val all = sheets.mapNotNull { layoutOf(it) }
        val foundOnes = all.filter { it.found }
        // لو في شيتات ليها عناوين معروفة نستخدمها بس ونتجاهل باقي الشيتات
        val use = if (foundOnes.isNotEmpty()) foundOnes else all
        val multi = use.size > 1
        val out = ArrayList<Account>()
        for (l in use) {
            var lastGroup = ""
            for (k in l.start until l.rows.size) {
                val r = l.rows[k]
                val get = { i: Int -> if (i >= 0 && i < r.size) r[i].trim() else "" }
                var g = get(l.gi)
                if (l.gi >= 0) {
                    if (g.isEmpty()) g = lastGroup else lastGroup = g
                }
                val email = get(l.ei)
                val pass = get(l.pi)
                if (email.isEmpty() && pass.isEmpty()) continue
                if (l.gi < 0) g = if (multi) l.sh.name else "عام"
                if (g.isEmpty()) g = "عام"
                var name = get(l.ni)
                if (name.isEmpty()) name = email
                out.add(Account(UUID.randomUUID().toString(), g, name, email, pass))
            }
        }
        return out
    }
}
