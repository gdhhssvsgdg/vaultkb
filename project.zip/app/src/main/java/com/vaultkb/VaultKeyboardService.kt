package com.vaultkb

import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class VaultKeyboardService : InputMethodService() {

    private var root: LinearLayout? = null
    private var selected: Account? = null
    private var curGroup: String? = null
    private var ownField = false
    private var lastPkg: String? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setBackgroundColor(Color.parseColor("#202124"))
        r.setPadding(dp(6), dp(6), dp(6), dp(6))
        root = r
        render()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val pkg = info?.packageName
        if (pkg != lastPkg) {
            selected = null
            curGroup = null
            lastPkg = pkg
        }
        ownField = (pkg == packageName)
        render()
        if (ownField) {
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    switchToPreviousInputMethod()
                } catch (e: Exception) {
                }
            }, 200)
        }
    }

    private fun weighted(): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        p.setMargins(dp(3), dp(3), dp(3), dp(3))
        return p
    }

    private fun btn(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setAllCaps(false)
        b.textSize = 15f
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(Color.parseColor("#3C4043"))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun label(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 14f
        v.setTextColor(Color.WHITE)
        v.setPadding(dp(6), dp(6), dp(6), dp(6))
        return v
    }

    private fun row(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        return r
    }

    private fun grid(labels: List<String>, onTap: (Int) -> Unit): ScrollView {
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        var i = 0
        while (i < labels.size) {
            val rw = row()
            val end = minOf(i + 2, labels.size)
            for (j in i until end) {
                val idx = j
                rw.addView(btn(labels[j]) { onTap(idx) }, weighted())
            }
            if (i + 1 >= labels.size) rw.addView(View(this), weighted())
            col.addView(rw)
            i += 2
        }
        sv.addView(col)
        return sv
    }

    private fun typeText(s: String) {
        currentInputConnection?.commitText(s, 1)
    }

    private fun render() {
        val r = root ?: return
        r.removeAllViews()
        val sel = selected
        val gridParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(190))

        if (ownField) {
            r.addView(label("بدّل للكيبورد العادي عشان تكتب بيانات الحساب (زرار ⌨)"))
        } else if (sel != null) {
            r.addView(label("الحساب: " + sel.name + "\nاضغط خانة الباسورد وبعدين «اكتب الباسورد»"))
            val rw = row()
            rw.addView(btn("اكتب الباسورد") { typeText(sel.password) }, weighted())
            rw.addView(btn("اكتب الإيميل") { typeText(sel.email) }, weighted())
            r.addView(rw)
            val back = row()
            back.addView(btn("رجوع للحسابات") {
                selected = null
                render()
            }, weighted())
            r.addView(back)
        } else {
            val all = Vault.load(this)
            if (all.isEmpty()) {
                r.addView(label("مفيش حسابات. افتح تطبيق «كيبورد الحسابات» وضيف حساباتك."))
            } else {
                val groups = ArrayList<String>()
                for (a in all) {
                    if (!groups.contains(a.group)) groups.add(a.group)
                }
                val cg = curGroup
                val g: String? =
                    if (groups.size == 1) groups[0]
                    else if (cg != null && groups.contains(cg)) cg
                    else null

                if (g == null) {
                    val names = groups.map { gr ->
                        gr + " (" + all.count { it.group == gr } + ")"
                    }
                    r.addView(grid(names) { idx ->
                        curGroup = groups[idx]
                        render()
                    }, gridParams)
                } else {
                    val items = all.filter { it.group == g }
                    if (groups.size > 1) {
                        val back = row()
                        back.addView(btn("↩ الفئات   |   " + g) {
                            curGroup = null
                            render()
                        }, weighted())
                        r.addView(back)
                    }
                    r.addView(grid(items.map { it.name }) { idx ->
                        val a = items[idx]
                        typeText(a.email)
                        selected = a
                        render()
                    }, gridParams)
                }
            }
        }

        val bar = row()
        bar.addView(btn("⌨") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, weighted())
        bar.addView(btn("مسح") {
            currentInputConnection?.deleteSurroundingText(500, 500)
        }, weighted())
        bar.addView(btn("⌫") { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) }, weighted())
        bar.addView(btn("↵") { sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) }, weighted())
        r.addView(bar)
    }
}
