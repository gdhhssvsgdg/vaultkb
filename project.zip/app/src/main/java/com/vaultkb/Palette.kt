package com.vaultkb

object Palette {
    val names = arrayOf("بدون لون", "أحمر", "أخضر", "أزرق", "أصفر")
    val dots = arrayOf("", "🔴", "🟢", "🔵", "🟡")
    val bg = intArrayOf(
        0,
        0xFFB3261E.toInt(),
        0xFF1E7B34.toInt(),
        0xFF1A5FB4.toInt(),
        0xFFB58900.toInt()
    )

    fun tag(a: Account): String {
        var s = ""
        if (a.color in 1..4) s += dots[a.color] + " "
        if (a.done) s += "✓ "
        return s
    }
}
