package com.vaultkb

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.UUID

class MainActivity : Activity() {

    private lateinit var nameIn: EditText
    private lateinit var emailIn: EditText
    private lateinit var passIn: EditText
    private lateinit var saveBtn: Button
    private lateinit var cancelBtn: Button
    private lateinit var listBox: LinearLayout
    private var editingId: String? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setAllCaps(false)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun field(hintText: String): EditText {
        val e = EditText(this)
        e.hint = hintText
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        e.setSingleLine(true)
        return e
    }

    private fun label(t: String, size: Float = 14f): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setPadding(0, dp(8), 0, dp(8))
        return v
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(32), dp(16), dp(32))
        scroll.addView(col)

        col.addView(label("كيبورد الحسابات", 24f))
        col.addView(
            label(
                "1) اضغط «تفعيل الكيبورد» وشغّله.\n" +
                    "2) في اللعبة اضغط على خانة الإيميل، واختار «كيبورد الحسابات» من زرار تبديل الكيبورد.\n" +
                    "3) اختار اسم الحساب فيكتب الإيميل، وبعدها اضغط خانة الباسورد واضغط «اكتب الباسورد».\n\n" +
                    "مهم: لازم تكتب بيانات الحساب هنا بالكيبورد العادي (مش كيبورد الحسابات)."
            )
        )

        val setupRow = LinearLayout(this)
        setupRow.orientation = LinearLayout.HORIZONTAL
        val lp = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
        setupRow.addView(button("تفعيل الكيبورد") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }, lp())
        setupRow.addView(button("اختيار الكيبورد") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, lp())
        col.addView(setupRow)

        col.addView(label("إضافة / تعديل حساب", 18f))
        nameIn = field("اسم الحساب (مثال: ببجي 1)")
        emailIn = field("الإيميل")
        passIn = field("الباسورد")
        col.addView(nameIn)
        col.addView(emailIn)
        col.addView(passIn)

        val formRow = LinearLayout(this)
        formRow.orientation = LinearLayout.HORIZONTAL
        saveBtn = button("حفظ") { save() }
        cancelBtn = button("إلغاء التعديل") { clearForm() }
        cancelBtn.visibility = View.GONE
        formRow.addView(saveBtn, lp())
        formRow.addView(cancelBtn, lp())
        col.addView(formRow)

        col.addView(label("حساباتك", 18f))
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        col.addView(listBox)

        setContentView(scroll)
        refresh()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun save() {
        val n = nameIn.text.toString().trim()
        val e = emailIn.text.toString().trim()
        val p = passIn.text.toString()
        if (n.isEmpty() || e.isEmpty() || p.isEmpty()) {
            toast("املا الاسم والإيميل والباسورد")
            return
        }
        val list = Vault.load(this).toMutableList()
        val id = editingId
        if (id == null) {
            list.add(Account(UUID.randomUUID().toString(), n, e, p))
        } else {
            val a = list.firstOrNull { it.id == id }
            if (a != null) {
                a.name = n
                a.email = e
                a.password = p
            }
        }
        Vault.save(this, list)
        clearForm()
        refresh()
        toast("اتحفظ")
    }

    private fun clearForm() {
        editingId = null
        nameIn.setText("")
        emailIn.setText("")
        passIn.setText("")
        saveBtn.text = "حفظ"
        cancelBtn.visibility = View.GONE
    }

    private fun startEdit(a: Account) {
        editingId = a.id
        nameIn.setText(a.name)
        emailIn.setText(a.email)
        passIn.setText(a.password)
        saveBtn.text = "حفظ التعديل"
        cancelBtn.visibility = View.VISIBLE
    }

    private fun confirmDelete(a: Account) {
        AlertDialog.Builder(this)
            .setMessage("تحذف «" + a.name + "»؟")
            .setPositiveButton("حذف") { _, _ ->
                val list = Vault.load(this).filter { it.id != a.id }
                Vault.save(this, list)
                if (editingId == a.id) clearForm()
                refresh()
            }
            .setNegativeButton("لأ", null)
            .show()
    }

    private fun refresh() {
        listBox.removeAllViews()
        val accounts = Vault.load(this)
        if (accounts.isEmpty()) {
            listBox.addView(label("لسه مفيش حسابات."))
            return
        }
        for (a in accounts) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val tv = label(a.name, 18f)
            row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button("تعديل") { startEdit(a) })
            row.addView(button("حذف") { confirmDelete(a) })
            listBox.addView(row)
        }
    }
}
