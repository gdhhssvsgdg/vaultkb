package com.vaultkb

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.UUID

class MainActivity : Activity() {

    private val reqImport = 101
    private val reqExport = 102

    private lateinit var scroll: ScrollView
    private lateinit var groupIn: AutoCompleteTextView
    private lateinit var nameIn: EditText
    private lateinit var emailIn: EditText
    private lateinit var passIn: EditText
    private lateinit var searchIn: EditText
    private lateinit var summary: TextView
    private lateinit var saveBtn: Button
    private lateinit var cancelBtn: Button
    private lateinit var listBox: LinearLayout
    private var editingId: String? = null
    private val collapsed = HashSet<String>()

    private lateinit var selBar: LinearLayout
    private lateinit var selCount: TextView
    private lateinit var selToggleBtn: Button
    private var selecting = false
    private val selectedIds = HashSet<String>()
    private val shownIds = ArrayList<String>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setAllCaps(false)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun field(hintText: String): EditText {
        val e = EditText(this)
        e.hint = hintText
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        e.setSingleLine(true)
        return e
    }

    private fun label(t: String, size: Float = 14f): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setPadding(0, dp(8), 0, dp(8))
        return v
    }

    private fun lp(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(32), dp(16), dp(32))
        scroll.addView(col)

        col.addView(label("كيبورد الحسابات  v2.5", 24f))
        col.addView(
            label(
                "1) اضغط «تفعيل الكيبورد» وشغّله.\n" +
                    "2) في اللعبة اضغط على خانة الإيميل واختار «كيبورد الحسابات» من زرار ⌨.\n" +
                    "3) اختار الفئة ثم الحساب فيكتب الإيميل، وبعدها اضغط خانة الباسورد واضغط «اكتب الباسورد».\n\n" +
                    "مهم: اكتب بياناتك هنا بالكيبورد العادي (مش كيبورد الحسابات)."
            )
        )

        val setupRow = LinearLayout(this)
        setupRow.orientation = LinearLayout.HORIZONTAL
        setupRow.addView(button("تفعيل الكيبورد") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }, lp())
        setupRow.addView(button("اختيار الكيبورد") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, lp())
        col.addView(setupRow)

        col.addView(label("استيراد / تصدير", 18f))
        col.addView(
            label(
                "ملف Excel (.xlsx) أو CSV. الصف الأول عناوين: الفئة | الاسم | الإيميل | الباسورد. " +
                    "لو مفيش عمود فئة، كل شيت بيتحول لفئة. الفئة الفاضية بتاخد فئة الصف اللي فوقها."
            )
        )
        val ioRow = LinearLayout(this)
        ioRow.orientation = LinearLayout.HORIZONTAL
        ioRow.addView(button("استيراد Excel/CSV") { pickImport() }, lp())
        ioRow.addView(button("تصدير CSV") { pickExport() }, lp())
        col.addView(ioRow)

        col.addView(label("إضافة / تعديل حساب", 18f))
        groupIn = AutoCompleteTextView(this)
        groupIn.hint = "الفئة (مثال: ببجي، يوتيوب)"
        groupIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        groupIn.setSingleLine(true)
        groupIn.threshold = 0
        groupIn.setOnClickListener { groupIn.showDropDown() }
        groupIn.setOnFocusChangeListener { _, has -> if (has) groupIn.showDropDown() }
        nameIn = field("اسم الحساب (مثال: ببجي 1)")
        emailIn = field("الإيميل")
        passIn = field("الباسورد")
        col.addView(groupIn)
        col.addView(nameIn)
        col.addView(emailIn)
        col.addView(passIn)

        val formRow = LinearLayout(this)
        formRow.orientation = LinearLayout.HORIZONTAL
        saveBtn = button("حفظ") { save() }
        cancelBtn = button("إلغاء التعديل") { clearForm() }
        cancelBtn.visibility = View.GONE
        formRow.addView(saveBtn, lp())
        formRow.addView(cancelBtn, lp())
        col.addView(formRow)

        col.addView(label("حساباتك", 18f))
        summary = label("")
        col.addView(summary)
        selToggleBtn = button("تحديد") { toggleSelecting() }
        col.addView(selToggleBtn)
        searchIn = field("بحث بالاسم أو الإيميل أو الفئة")
        col.addView(searchIn)

        selBar = LinearLayout(this)
        selBar.orientation = LinearLayout.VERTICAL
        selBar.visibility = View.GONE
        selCount = label("محدد: 0")
        selBar.addView(selCount)
        val selRow1 = LinearLayout(this)
        selRow1.orientation = LinearLayout.HORIZONTAL
        selRow1.addView(button("تحديد الكل") { selectAllShown() }, lp())
        selRow1.addView(button("إلغاء التحديد") {
            selectedIds.clear()
            updateSelCount()
            refresh()
        }, lp())
        val selRow2 = LinearLayout(this)
        selRow2.orientation = LinearLayout.HORIZONTAL
        selRow2.addView(button("نقل لفئة") { moveSelected() }, lp())
        selRow2.addView(button("حذف المحدد") { deleteSelected() }, lp())
        val selRow3 = LinearLayout(this)
        selRow3.orientation = LinearLayout.HORIZONTAL
        selRow3.addView(button("علّم ✓ تم") { setDoneSelected(true) }, lp())
        selRow3.addView(button("شيل علامة ✓") { setDoneSelected(false) }, lp())
        selBar.addView(selRow1)
        selBar.addView(selRow2)
        selBar.addView(selRow3)
        col.addView(selBar)

        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        col.addView(listBox)

        searchIn.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                refresh()
            }
        })

        setContentView(scroll)
        refresh()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // ---------------- form ----------------

    private fun save() {
        var g = groupIn.text.toString().trim()
        if (g.isEmpty()) g = "عام"
        val n = nameIn.text.toString().trim()
        val e = emailIn.text.toString().trim()
        val p = passIn.text.toString()
        if (n.isEmpty() || e.isEmpty() || p.isEmpty()) {
            toast("املا الاسم والإيميل والباسورد")
            return
        }
        val list = Vault.load(this).toMutableList()
        val id = editingId
        if (id == null) {
            list.add(Account(UUID.randomUUID().toString(), g, n, e, p))
        } else {
            val a = list.firstOrNull { it.id == id }
            if (a != null) {
                a.group = g
                a.name = n
                a.email = e
                a.password = p
            }
        }
        Vault.save(this, list)
        clearForm()
        refresh()
        toast("اتحفظ")
    }

    private fun clearForm() {
        editingId = null
        groupIn.setText("", false)
        nameIn.setText("")
        emailIn.setText("")
        passIn.setText("")
        saveBtn.text = "حفظ"
        cancelBtn.visibility = View.GONE
    }

    private fun startEdit(a: Account) {
        editingId = a.id
        groupIn.setText(a.group, false)
        nameIn.setText(a.name)
        emailIn.setText(a.email)
        passIn.setText(a.password)
        saveBtn.text = "حفظ التعديل"
        cancelBtn.visibility = View.VISIBLE
        scroll.smoothScrollTo(0, 0)
    }

    private fun confirmDelete(a: Account) {
        AlertDialog.Builder(this)
            .setMessage("تحذف «" + a.name + "»؟")
            .setPositiveButton("حذف") { _, _ ->
                Vault.save(this, Vault.load(this).filter { it.id != a.id })
                if (editingId == a.id) clearForm()
                refresh()
            }
            .setNegativeButton("لأ", null)
            .show()
    }

    // ---------------- groups ----------------

    private fun renameGroup(g: String) {
        val et = EditText(this)
        et.setText(g)
        AlertDialog.Builder(this)
            .setTitle("اسم الفئة الجديد")
            .setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    val list = Vault.load(this)
                    for (a in list) {
                        if (a.group == g) a.group = n
                    }
                    Vault.save(this, list)
                    collapsed.remove(g)
                    refresh()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun deleteGroup(g: String, count: Int) {
        AlertDialog.Builder(this)
            .setMessage("تحذف فئة «" + g + "» بكل حساباتها (" + count + ")؟")
            .setPositiveButton("حذف") { _, _ ->
                Vault.save(this, Vault.load(this).filter { it.group != g })
                collapsed.remove(g)
                refresh()
            }
            .setNegativeButton("لأ", null)
            .show()
    }

    // ---------------- list ----------------

    private fun refresh() {
        listBox.removeAllViews()
        shownIds.clear()
        val all = Vault.load(this)
        val q = searchIn.text.toString().trim().lowercase()

        val groups = LinkedHashMap<String, MutableList<Account>>()
        for (a in all) {
            var l = groups[a.group]
            if (l == null) {
                l = ArrayList()
                groups[a.group] = l
            }
            l.add(a)
        }
        groupIn.setAdapter(
            ArrayAdapter<String>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                groups.keys.toList()
            )
        )
        summary.text = all.size.toString() + " حساب في " + groups.size + " فئة، منهم " +
            all.count { it.done } + " اتسجّل ✓"

        if (all.isEmpty()) {
            listBox.addView(label("لسه مفيش حسابات."))
            return
        }

        for ((g, items) in groups) {
            val shown = if (q.isEmpty()) items else items.filter {
                it.name.lowercase().contains(q) || it.email.lowercase().contains(q) ||
                    g.lowercase().contains(q)
            }
            if (shown.isEmpty()) continue
            for (a in shown) shownIds.add(a.id)
            val open = q.isNotEmpty() || !collapsed.contains(g)

            val head = LinearLayout(this)
            head.orientation = LinearLayout.HORIZONTAL
            head.gravity = Gravity.CENTER_VERTICAL
            head.setBackgroundColor(0xFFE8EAED.toInt())
            head.setPadding(dp(8), dp(2), dp(8), dp(2))
            if (selecting) {
                val gcb = CheckBox(this)
                val ids = shown.map { it.id }
                gcb.isChecked = ids.isNotEmpty() && selectedIds.containsAll(ids)
                gcb.setOnClickListener {
                    if (gcb.isChecked) selectedIds.addAll(ids) else selectedIds.removeAll(ids.toSet())
                    updateSelCount()
                    refresh()
                }
                head.addView(gcb)
            }
            val title = TextView(this)
            title.text = (if (open) "▼ " else "▶ ") + g + " (" + items.count { it.done } + "/" + items.size + ")"
            title.textSize = 18f
            title.setOnClickListener {
                if (collapsed.contains(g)) collapsed.remove(g) else collapsed.add(g)
                refresh()
            }
            head.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
            head.addView(button("✎") { renameGroup(g) })
            head.addView(button("🗑") { deleteGroup(g, items.size) })
            val hp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            hp.topMargin = dp(10)
            listBox.addView(head, hp)

            if (!open) continue
            for (a in shown) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                val tv = TextView(this)
                tv.text = (if (a.done) "✓ " else "") + a.name + "\n" + a.email
                tv.textSize = 16f
                tv.setPadding(dp(8), dp(6), 0, dp(6))
                if (selecting) {
                    val cb = CheckBox(this)
                    cb.isChecked = selectedIds.contains(a.id)
                    cb.setOnCheckedChangeListener { _, checked ->
                        if (checked) selectedIds.add(a.id) else selectedIds.remove(a.id)
                        updateSelCount()
                    }
                    tv.setOnClickListener { cb.isChecked = !cb.isChecked }
                    row.addView(cb)
                    row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                } else {
                    row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                    row.addView(button(if (a.done) "↩" else "✓") { toggleDone(a) })
                    row.addView(button("تعديل") { startEdit(a) })
                    row.addView(button("حذف") { confirmDelete(a) })
                }
                listBox.addView(row)
            }
        }
    }

    // ---------------- done marks ----------------

    private fun toggleDone(a: Account) {
        Vault.setDone(this, a.id, !a.done)
        refresh()
    }

    private fun setDoneSelected(v: Boolean) {
        if (selectedIds.isEmpty()) {
            toast("حدد حسابات الأول")
            return
        }
        val ids = HashSet(selectedIds)
        val list = Vault.load(this)
        for (a in list) {
            if (ids.contains(a.id)) a.done = v
        }
        Vault.save(this, list)
        selectedIds.clear()
        updateSelCount()
        refresh()
    }

    // ---------------- selection ----------------

    private fun updateSelCount() {
        selCount.text = "محدد: " + selectedIds.size
    }

    private fun toggleSelecting() {
        selecting = !selecting
        selectedIds.clear()
        selToggleBtn.text = if (selecting) "إنهاء التحديد" else "تحديد"
        selBar.visibility = if (selecting) View.VISIBLE else View.GONE
        updateSelCount()
        refresh()
    }

    private fun selectAllShown() {
        selectedIds.addAll(shownIds)
        updateSelCount()
        refresh()
    }

    private fun moveSelected() {
        if (selectedIds.isEmpty()) {
            toast("حدد حسابات الأول")
            return
        }
        val groups = Vault.load(this).map { it.group }.distinct()
        val items = (groups + "＋ فئة جديدة").toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("نقل " + selectedIds.size + " حساب إلى")
            .setItems(items) { _, which ->
                if (which < groups.size) doMove(groups[which]) else askNewGroup()
            }
            .show()
    }

    private fun askNewGroup() {
        val et = EditText(this)
        et.hint = "اسم الفئة الجديدة"
        AlertDialog.Builder(this)
            .setTitle("فئة جديدة")
            .setView(et)
            .setPositiveButton("نقل") { _, _ -> doMove(et.text.toString().trim()) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun doMove(g: String) {
        if (g.isEmpty()) {
            toast("اكتب اسم الفئة")
            return
        }
        val ids = HashSet(selectedIds)
        val list = Vault.load(this)
        for (a in list) {
            if (ids.contains(a.id)) a.group = g
        }
        Vault.save(this, list)
        selectedIds.clear()
        updateSelCount()
        refresh()
        toast("اتنقل " + ids.size + " حساب لفئة " + g)
    }

    private fun deleteSelected() {
        if (selectedIds.isEmpty()) {
            toast("حدد حسابات الأول")
            return
        }
        val n = selectedIds.size
        AlertDialog.Builder(this)
            .setMessage("تحذف " + n + " حساب؟")
            .setPositiveButton("حذف") { _, _ ->
                val ids = HashSet(selectedIds)
                Vault.save(this, Vault.load(this).filter { !ids.contains(it.id) })
                val e = editingId
                if (e != null && ids.contains(e)) clearForm()
                selectedIds.clear()
                updateSelCount()
                refresh()
                toast("اتحذف " + n)
            }
            .setNegativeButton("لأ", null)
            .show()
    }

    // ---------------- import / export ----------------

    private fun pickImport() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, reqImport)
    }

    private fun pickExport() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "text/csv"
        i.putExtra(Intent.EXTRA_TITLE, "accounts.csv")
        startActivityForResult(i, reqExport)
    }

    private fun csv(s: String): String = "\"" + s.replace("\"", "\"\"") + "\""

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return

        if (requestCode == reqImport) {
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                val items = SheetImport.parse(bytes)
                if (items.isEmpty()) {
                    toast("مالقيتش حسابات في الملف")
                    return
                }
                val gc = items.map { it.group }.toSet().size
                AlertDialog.Builder(this)
                    .setMessage("لقيت " + items.size + " حساب في " + gc + " فئة.")
                    .setPositiveButton("ضيف على الحالي") { _, _ -> applyImport(items, false) }
                    .setNegativeButton("استبدل الكل") { _, _ -> applyImport(items, true) }
                    .setNeutralButton("إلغاء", null)
                    .show()
            } catch (e: Exception) {
                toast("مقدرتش أقرا الملف: " + (e.message ?: ""))
            }
        } else if (requestCode == reqExport) {
            try {
                val sb = StringBuilder("\uFEFF")
                sb.append("الفئة,الاسم,الإيميل,الباسورد,تم التسجيل\n")
                for (a in Vault.load(this)) {
                    sb.append(csv(a.group)).append(',')
                        .append(csv(a.name)).append(',')
                        .append(csv(a.email)).append(',')
                        .append(csv(a.password)).append(',')
                        .append(csv(if (a.done) "✓" else "")).append('\n')
                }
                contentResolver.openOutputStream(uri)!!.use {
                    it.write(sb.toString().toByteArray(Charsets.UTF_8))
                }
                toast("اتصدّر. الملف فيه الباسوردات بدون تشفير، خلي بالك منه")
            } catch (e: Exception) {
                toast("فشل التصدير: " + (e.message ?: ""))
            }
        }
    }

    private fun applyImport(items: List<Account>, replace: Boolean) {
        val list: MutableList<Account> =
            if (replace) ArrayList() else Vault.load(this).toMutableList()
        var added = 0
        var updated = 0
        for (n in items) {
            val ex = list.firstOrNull {
                if (n.email.isNotEmpty()) it.email.equals(n.email, ignoreCase = true)
                else (it.group == n.group && it.name == n.name)
            }
            if (ex != null) {
                ex.group = n.group
                ex.name = n.name
                ex.email = n.email
                ex.password = n.password
                if (n.done) ex.done = true
                updated++
            } else {
                list.add(n)
                added++
            }
        }
        Vault.save(this, list)
        refresh()
        toast("اتضاف " + added + " واتحدّث " + updated)
    }
}
