plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vaultkb"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vaultkb"
        minSdk = 24
        targetSdk = 34
        versionCode = 6
        versionName = "2.4"
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("vault.keystore")
            storePassword = "vaultkb123"
            keyAlias = "vault"
            keyPassword = "vaultkb123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
