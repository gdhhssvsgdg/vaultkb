# LOCKED IN

1. Make a new GitHub repo and upload everything in this folder (keep the .github folder).
2. Open the Actions tab, pick "Build APK", press Run workflow (it also runs on every push).
3. When it turns green, open the run and download LOCKED-IN-apk from Artifacts. Unzip it and install app-debug.apk on your phone.

To change the app, edit www/index.html and push.
